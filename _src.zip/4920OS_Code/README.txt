To index a csv file use the post.jar in solr folder with the following command

java -Durl=http://localhost:8983/solr/update -Dtype=application/csv -jar post.jar books2.csv

You will need to index books.csv file in chapter folder code for running code of different folders
